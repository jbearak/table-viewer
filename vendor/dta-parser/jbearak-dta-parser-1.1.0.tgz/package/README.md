# @jbearak/dta-parser

Read Stata `.dta` files (releases 104 to 119) and write release 118,
and read and write Parquet files that keep a `.dta` file's labels and
`.a` to `.z`, in Node, synchronously. Both formats are implemented once,
in Rust, and run here as an embedded wasm module.

```ts
import { openDta, formatValue, MISSING, type Missing } from "@jbearak/dta-parser";
import { openDtaFile, writeDtaFile } from "@jbearak/dta-parser/node";

const r = openDtaFile("survey.dta");       // or openDta(bytes)
r.info;                                    // release, nobs, label, timestamp, encoding, sortedBy
r.variables;                               // name, type, format, label, valueLabels
const [age, region] = r.readColumns(["age", "region"], { start: 0, count: 1000 });
const rows = r.readRows(0, 20);            // cells: number | string | Uint8Array | Missing
r.valueLabels("yesno")?.get(MISSING[".d"]);
formatValue(rows[0][0], r.variables[0].format, r.valueLabels(r.variables[0].valueLabels));
r.close();

writeDtaFile("out.dta", {
  label: "Example",
  valueLabels: { yesno: new Map<number | Missing, string>([[0, "No"], [1, "Yes"], [MISSING[".d"], "Don't know"]]) },
  variables: [
    { name: "answer", type: "byte", values: [1, 0, MISSING[".d"]], valueLabels: "yesno" },
    { name: "note", values: ["a", "b", "c"] },
    { name: "blob", values: [new Uint8Array([0, 1]), "text", ""] }, // a Uint8Array is a binary strL
  ],
  // also: notes, characteristics, sortedBy, timestamp (a Date, or text as r.info.timestamp)
});
```

Parquet files keep labels, `.a` to `.z`, categoricals and time zones,
and are read through the same reader interface (`TableReader`):

```ts
import { openParquet, writeParquet, toDate } from "@jbearak/dta-parser";
import { openParquetFile, writeParquetFile } from "@jbearak/dta-parser/node";

writeParquetFile("out.parquet", { variables: [{ name: "x", values: [1, 2] }] }); // writeDta's dataset; snappy
const p = openParquetFile("out.parquet");  // reads the footer only; or openParquet(bytes), openParquetAsync(readAt, size)
p.readColumns(["x"], { start: 0, count: 2 });
p.close();
```

A file is read only as far as asked: opening reads the header and the
variable descriptors, and `readColumns` decodes just the requested
variables and rows. Each call into the module holds at most 64 MiB of
decoded data. See [docs/migration.md](https://github.com/jbearak/dta-parser/blob/main/docs/migration.md)
for moving from 0.x.

The open-source projects studied for the Parquet code, and the codec
crates it uses, are listed with their licenses in
[docs/acknowledgements.md](https://github.com/jbearak/dta-parser/blob/main/docs/acknowledgements.md);
the crates' licence texts are in `THIRD-PARTY-NOTICES`.
